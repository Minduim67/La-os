﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form8
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.Ex1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Ex2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Ex3ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Ex4ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Ex5ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Ex6ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Ex7ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Ex8ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Ex9ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Ex10ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button3
        '
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.ForeColor = System.Drawing.Color.Red
        Me.Button3.Location = New System.Drawing.Point(169, 342)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(86, 38)
        Me.Button3.TabIndex = 19
        Me.Button3.Text = "Limpar"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.ForeColor = System.Drawing.Color.Red
        Me.Button2.Location = New System.Drawing.Point(35, 342)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(86, 38)
        Me.Button2.TabIndex = 18
        Me.Button2.Text = "Encerrar"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.ForeColor = System.Drawing.Color.Red
        Me.Button1.Location = New System.Drawing.Point(231, 209)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(86, 38)
        Me.Button1.TabIndex = 17
        Me.Button1.Text = "Processar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Red
        Me.Label3.Location = New System.Drawing.Point(12, 190)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(207, 16)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "Digite a Quantidade de Números:"
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(332, 129)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(156, 251)
        Me.ListBox1.TabIndex = 15
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(49, 209)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(166, 20)
        Me.TextBox1.TabIndex = 14
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Red
        Me.Label2.Location = New System.Drawing.Point(0, 90)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(514, 49)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Este Programa Lê a quantidade de Números digitadas e Mostra se eles são Pares ou " & _
    "Ímpares"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Red
        Me.Label1.Location = New System.Drawing.Point(140, 46)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(230, 31)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Ex 8 - Par e Ímpar"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Ex1ToolStripMenuItem, Me.Ex2ToolStripMenuItem, Me.Ex3ToolStripMenuItem, Me.Ex4ToolStripMenuItem, Me.Ex5ToolStripMenuItem, Me.Ex6ToolStripMenuItem, Me.Ex7ToolStripMenuItem, Me.Ex8ToolStripMenuItem, Me.Ex9ToolStripMenuItem, Me.Ex10ToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(526, 24)
        Me.MenuStrip1.TabIndex = 11
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Ex1ToolStripMenuItem
        '
        Me.Ex1ToolStripMenuItem.Name = "Ex1ToolStripMenuItem"
        Me.Ex1ToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.Ex1ToolStripMenuItem.Text = "Ex1"
        '
        'Ex2ToolStripMenuItem
        '
        Me.Ex2ToolStripMenuItem.Name = "Ex2ToolStripMenuItem"
        Me.Ex2ToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.Ex2ToolStripMenuItem.Text = "Ex2"
        '
        'Ex3ToolStripMenuItem
        '
        Me.Ex3ToolStripMenuItem.Name = "Ex3ToolStripMenuItem"
        Me.Ex3ToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.Ex3ToolStripMenuItem.Text = "Ex3"
        '
        'Ex4ToolStripMenuItem
        '
        Me.Ex4ToolStripMenuItem.Name = "Ex4ToolStripMenuItem"
        Me.Ex4ToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.Ex4ToolStripMenuItem.Text = "Ex4"
        '
        'Ex5ToolStripMenuItem
        '
        Me.Ex5ToolStripMenuItem.Name = "Ex5ToolStripMenuItem"
        Me.Ex5ToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.Ex5ToolStripMenuItem.Text = "Ex5"
        '
        'Ex6ToolStripMenuItem
        '
        Me.Ex6ToolStripMenuItem.Name = "Ex6ToolStripMenuItem"
        Me.Ex6ToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.Ex6ToolStripMenuItem.Text = "Ex6"
        '
        'Ex7ToolStripMenuItem
        '
        Me.Ex7ToolStripMenuItem.Name = "Ex7ToolStripMenuItem"
        Me.Ex7ToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.Ex7ToolStripMenuItem.Text = "Ex7"
        '
        'Ex8ToolStripMenuItem
        '
        Me.Ex8ToolStripMenuItem.Name = "Ex8ToolStripMenuItem"
        Me.Ex8ToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.Ex8ToolStripMenuItem.Text = "Ex8"
        '
        'Ex9ToolStripMenuItem
        '
        Me.Ex9ToolStripMenuItem.Name = "Ex9ToolStripMenuItem"
        Me.Ex9ToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.Ex9ToolStripMenuItem.Text = "Ex9"
        '
        'Ex10ToolStripMenuItem
        '
        Me.Ex10ToolStripMenuItem.Name = "Ex10ToolStripMenuItem"
        Me.Ex10ToolStripMenuItem.Size = New System.Drawing.Size(43, 20)
        Me.Ex10ToolStripMenuItem.Text = "Ex10"
        '
        'Form8
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Gold
        Me.ClientSize = New System.Drawing.Size(526, 392)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MaximumSize = New System.Drawing.Size(542, 431)
        Me.MinimumSize = New System.Drawing.Size(542, 431)
        Me.Name = "Form8"
        Me.Text = "Form8"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Ex1ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Ex2ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Ex3ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Ex4ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Ex5ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Ex6ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Ex7ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Ex8ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Ex9ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Ex10ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
